import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';

import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
@Component({
  selector: 'app-marking',
  imports: [
    CommonModule, ReactiveFormsModule, MatButtonModule
  ],
  templateUrl: './marking.html',
  styleUrls: ['./marking.scss'],
})
export class Marking {
  private fb = inject(FormBuilder);

  countries = ['INDIA', 'UAE', 'OMAN', 'USA'];

  // ✅ backend images (later)
  topPreviewUrl: string | null = null;
  midPreviewUrl: string | null = null;
  rightPreviewUrl: string | null = null;
  tinyPreviewUrl: string | null = null;

  form = this.fb.group({
    modelNo: [''],
    description: [''],
    description1: [''],
    market: [''],
    driveType: [''],
    flw: [''],
    faw: [''],
    seatCode: [''],
    engine: [''],
    batchNo: ['700071'],

    country: ['INDIA'],
    trim: [''],
    gvw: [''],
    raw: [''],
    color: [''],
    bsStage: [''],
    date: [''],

    vinNo: [''],
    engineSrNo: [''],

    cngTankId: [''],
    dtOfInstall: [''],
    dtOfLastRetest: [''],
    waterCapacity: [''],
    vinLast8: [''],

    sticker: ['VIN'],
  });

  clear() {
    this.form.reset({ batchNo: '700071', country: 'INDIA', sticker: 'VIN' });
  }

  startMarking() {
    console.log('MARKING', this.form.getRawValue());
  }
}
