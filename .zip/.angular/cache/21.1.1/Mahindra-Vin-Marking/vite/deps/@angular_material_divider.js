import {
  MatDivider,
  MatDividerModule
} from "./chunk-VROTDKBS.js";
import "./chunk-42QFQP6S.js";
import "./chunk-N4DOILP3.js";
import "./chunk-K4EFZKPC.js";
import "./chunk-X56DGR4G.js";
import "./chunk-X7PJ4IBP.js";
import "./chunk-GOMI4DH3.js";
export {
  MatDivider,
  MatDividerModule
};
